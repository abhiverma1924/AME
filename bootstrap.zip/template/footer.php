      	<hr>

      	<footer style="background-color: #6DA8C3;">
        	<div class="text-muted pull-right" >
          		<a href="admin.php" style="color:black; font:luna; font-size: 30px; background-color: orange;">Admin Login</a>
        	</div>
      	</footer>
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="./bootstrap/js/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>