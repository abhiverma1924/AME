<?php
//all the variables defined here are accessible in all the files that include this one
$conn= new mysqli('localhost','aab96cb9_aviator','Abhiverma@1819')or die("Could not connect to mysql".mysqli_error($conn));

?>